package handlingExceptions;

public class DemoException {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Thread.sleep(2000);
		
		int a=10;
		int b=0;
		int d=a/b;
		System.out.println(d);
	}

}
